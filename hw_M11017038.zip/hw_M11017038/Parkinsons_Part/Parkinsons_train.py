import pandas as pd
import matplotlib.pyplot as plt
import pydotplus
from sklearn import tree
from sklearn import datasets
from sklearn.tree import DecisionTreeClassifier , plot_tree

# read parkinsons .csv file
Parkinsons = pd.read_csv("parkinsons_train.csv" , encoding = 'unicode_escape')
features = list(Parkinsons.columns[:8]) # 取8個特徵

X = Parkinsons[features]
y = Parkinsons['total_UPDRS']

from sklearn.model_selection import train_test_split
X_train , X_test , y_train , y_test = train_test_split(X , y , test_size = 0.3) # 70%訓練用 30%測試用
clf = tree.DecisionTreeClassifier(criterion = 'entropy' , max_depth = 10 , max_leaf_nodes = 170).fit(X_train , y_train)
clf.score(X_train , y_train)
clf.predict(X_test)
clf.score(X_test , y_test)

# 劃出決策樹
fig , ax = plt.subplots(figsize = (30,20))
plot_tree(clf , ax = ax , feature_names = features);

# 輸出決策樹到pdf檔
dot_data = tree.export_graphviz(clf , out_file = None)
graph = pydotplus.graph_from_dot_data(dot_data)
graph.write_pdf('Parkinsons_tree_10_170.pdf')