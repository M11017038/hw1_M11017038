import pandas as pd
import matplotlib.pyplot as plt
import pydotplus
from sklearn import tree
from sklearn import datasets
from sklearn.tree import DecisionTreeClassifier , plot_tree

# read adult .csv file
Adult = pd.read_csv("adult_train.csv" , encoding = 'unicode_escape')
features = list(Parkinsons.columns[:4]) # 取4個特徵

X = Parkinsons[features]
y = Parkinsons['class']

from sklearn.model_selection import train_test_split
X_train , X_test , y_train , y_test = train_test_split(X , y , test_size = 0.3) # 70%訓練用 30%測試用
clf = tree.DecisionTreeClassifier(criterion = 'entropy' , max_depth = 5 , max_leaf_nodes = 50).fit(X_train , y_train)
clf.score(X_train , y_train)
clf.predict(X_test)
clf.score(X_test , y_test)

# 劃出決策樹
fig , ax = plt.subplots(figsize = (30,20))
plot_tree(clf , ax = ax , feature_names = features , class_names = y);

# 輸出決策樹到pdf檔
dot_data = tree.export_graphviz(clf , class_names = y , out_file = None)
graph = pydotplus.graph_from_dot_data(dot_data)
graph.write_pdf('adult_tree_5_50.pdf')